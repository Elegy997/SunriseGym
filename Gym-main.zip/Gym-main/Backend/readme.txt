NodeJS
(Aztán majd MongoDB)

Lépések:
(Töltsd le a repót zip-ben vagy klónozd a repót)
- Nyisd meg a Backend mappát Visual Studio Code-ban
- Nyisd meg a Git Bash-t (Ctrl+Ö-vel megnyílik a terminál, jobb felső sarkában a "+" melletti nyíllal ki tudod választani a Git Bash-t)
- Írd be "npm i" vagy "npm install"
- Írd be "npm run dev"
- Böngészőbe írd be "localhost:3500"
(Annak kell megjelennie, hogy "Főoldal")
